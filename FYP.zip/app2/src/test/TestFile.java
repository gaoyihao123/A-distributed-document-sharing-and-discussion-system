package test;

import java.io.File;

public class TestFile {

    public static void main(String[] args) {
        File file =  new File("D:\\downloads\\fr-plugin-bi-tools-1.0(2).zip");
        System.out.println(file.length());
    }
}
