package test.client;

import javafx.concurrent.Task;
import main.entity.CommonMessage;
import main.entity.FileFromTorrent;
import main.entity.MessageType;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Objects;

public class PeerClientTask implements Runnable {

    private final static int BUFFER_SIZE = 8;

    private boolean req;    /** 请求标志 */
    private boolean resAck; /** 响应方标确认 */
    private Socket socket;
    private FileFromTorrent downloadFile;
    private String absolutePath;

    private byte [] recvBuffer = new byte[1024 * BUFFER_SIZE];

    public PeerClientTask(FileFromTorrent downloadFile, String absolutePath) {
        this.downloadFile = downloadFile;
        this.absolutePath = absolutePath;
        socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(downloadFile.getIpv4Addr(), downloadFile.getPort()));
        } catch (Exception e){
            e.printStackTrace();
            try {
                socket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {

            }
        }
    }

    {
        req = false;
        resAck = false;
        absolutePath = "D:/downloads/";
    }

    @Override
    public void run()  {
        ObjectOutputStream oos = null;
        ObjectInputStream  ois = null;
        DataInputStream    dis = null;
        FileOutputStream   fos = null;
        long        fileLength = downloadFile.getLength();
        long        downloaded = 0;
        long   stageDownloaded = 0;
        long stageLimit;
        int len;
        stageLimit = fileLength > 10000 ? fileLength/10000 : 100;
        CommonMessage resFileExist = null;
        try {
            /** 打开流 */
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
            dis = new DataInputStream(socket.getInputStream());
            fos = new FileOutputStream(new File(absolutePath + downloadFile.getFileName()));
            CommonMessage askFileExist = CommonMessage.createAskFileExists(downloadFile, "");

            while(!this.req && !this.resAck) {
                System.out.println("发送给文件名" + askFileExist.getFileFromTorrent().getFileName() + "是否存在？");
                oos.writeObject(askFileExist);
                this.req = true;
                break;
            }
            while(this.req && !this.resAck) {
                if(Objects.nonNull(resFileExist = (CommonMessage)ois.readObject())) {
                    if(resFileExist.getMessageType().equals(MessageType.FILE_EXIST_SIGNAL)) {
                        System.out.println("客户端收到文件存在，发送请求传输信号，文件的hash值：" + resFileExist.getInfo());
                        oos.writeObject(CommonMessage.createStartTrans());
                    }
                    this.resAck = true;
                }
            }
            while ((len = dis.read(recvBuffer, 0, recvBuffer.length)) > 0) {
                stageDownloaded += BUFFER_SIZE;
                if(stageDownloaded >= stageLimit) {
                    downloaded += stageDownloaded;
                    stageDownloaded = 0;
                }
                fos.write(recvBuffer, 0, len);
                fos.flush();
            }
            downloaded += stageDownloaded;
        } catch(Exception e) {
            e.printStackTrace();
        }
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        }
    }

    public static void main(String[] args) {
        new Thread(new PeerClientTask( new FileFromTorrent(
                "1.zip",
                "D:\\1.zip",
                "127.0.0.1",
                35789,
                "1321q3",
                12312l
        ),"E:\\")).start();
    }
}
