package test.client;

public class TestSerializable {
}
