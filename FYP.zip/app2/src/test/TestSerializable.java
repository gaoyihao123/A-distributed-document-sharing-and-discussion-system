package test;

import java.io.*;

public class TestSerializable implements Serializable {

    public static final long serialVersionUID = -5809782578272943999L;
    public String fileName;
    public String absolutePath;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public TestSerializable(String fileName, String absolutePath) {
        this.fileName = fileName;
        this.absolutePath = absolutePath;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getAbsolutePath() {
        return absolutePath;
    }

    public void setAbsolutePath(String absolutePath) {
        this.absolutePath = absolutePath;
    }

    @Override
    public String toString() {
        return "TestSerializable{" +
                "fileName='" + fileName + '\'' +
                ", absolutePath='" + absolutePath + '\'' +
                '}';
    }

//    public static void main(String[] args) throws Exception{
//        SerializableObj();
//        TestSerializable obj = DeserializeObj();
//        System.out.println(obj);
//    }
//
//    private static void SerializableObj() throws FileNotFoundException, IOException {
//        TestSerializable obj = new TestSerializable("1.xmk", "E:/");
//        // ObjectOutputStream 对象输出流，将Person对象存储到E盘的Person.txt文件中，完成对Person对象的序列化操作
//        ObjectOutputStream oo = new ObjectOutputStream(new FileOutputStream(
//                new File("E:/Person.txt")));
//        oo.writeObject(obj);
//        System.out.println("Person对象序列化成功！");
//        oo.close();
//    }
//
//    private static TestSerializable DeserializeObj() throws Exception, IOException {
//        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(
//                new File("E:/Person.txt")));
//        TestSerializable person = (TestSerializable) ois.readObject();
//        System.out.println("Person对象反序列化成功！");
//        return person;
//    }
}
