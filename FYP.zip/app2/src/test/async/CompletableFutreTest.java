//package test.async;
//
//import app.test.utils.HashFile;
//import app.vo.FileFromTorrentVo;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.CompletableFuture;
//import java.util.concurrent.ExecutionException;
//import java.util.stream.Collectors;
//
//public class CompletableFutreTest {
//    public static void futureTest() {
//        CompletableFuture<String> future1 = CompletableFuture.supplyAsync(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            System.out.println("future1 finished!");
//            return "future1 finished!";
//        });
//        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(() -> {
//            System.out.println("future2 finished!");
//            return "future2 finished!";
//        });
//        CompletableFuture<Void> combindFuture = CompletableFuture.allOf(future1, future2);
//        try {
//            combindFuture.get();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }
//        System.out.println("future1: " + future1.isDone() + " future2: " + future2.isDone());
//    }
//
//    public static void testHashFileAsync() {
//        List<File> files = new ArrayList<File>() {{
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//        }};
//        @SuppressWarnings({"unchecked"})
//        List<CompletableFuture<FileFromTorrentVo>> t = files.stream().map(e -> {
//            return CompletableFuture.supplyAsync(() -> {
//                String hash = HashFile.getFileMD5(e);
//                long len = e.getTotalSpace();
//                return new FileFromTorrentVo(e.getName(), e.getAbsolutePath(), "127.0.0.1", "3000");
//            }).whenComplete( (r, ex) -> {
////                System.out.println(r.toString());
//            });
//        }).collect(Collectors.toList());
//        CompletableFuture<FileFromTorrentVo> [] b = new CompletableFuture[t.size()];
//        b = t.toArray(b);
//
//        CompletableFuture<Void> combindFuture = CompletableFuture.allOf(b);
//        try {
//
//            combindFuture.get();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        } finally {
//        }
//    }
//
//    public static void testHashFileSync() {
//        List<File> files = new ArrayList<File>() {{
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//        }};
//        files.stream().map(e -> {
//            String hash = HashFile.getFileMD5(e);
////            System.out.println(e.getName());
//            return null;
//        }).collect(Collectors.toList());
//    }
//
//
//    public static void testHashFileAsync2() {
//        List<File> files = new ArrayList<File>() {{
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//            add(new File("C:\\Users\\Admin\\Desktop\\pdi-ce-8.2.0.0-342.zip"));
//            add(new File("F:\\astah-professional-7_2_0-1ff236(1).zip"));
//            add(new File("F:\\Navicat.Premium.12.1.8.rar"));
//        }};
//        files.parallelStream().map(e -> {
//            String hash = HashFile.getFileMD5(e);
//            return null;
//        }).collect(Collectors.toList());
//    }
//
//
//    public static void main(String[] args) {
////        futureTest();
//        long startTime = System.currentTimeMillis();
//        testHashFileSync();
//        long endTime = System.currentTimeMillis();
//        System.out.println(endTime-startTime);
//        System.out.println("****************************");
//        startTime = System.currentTimeMillis();
//               testHashFileAsync();
//        endTime = System.currentTimeMillis();
//        System.out.println(endTime-startTime);
//        System.out.println("****************************");
//        startTime = System.currentTimeMillis();
//        testHashFileAsync2();
//        endTime = System.currentTimeMillis();
//        System.out.println(endTime-startTime);
//        /**  */
//    }
//}
