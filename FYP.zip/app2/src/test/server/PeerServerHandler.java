package test.server;

import main.entity.CommonMessage;
import main.entity.FileFromTorrent;
import main.entity.MessageType;
import main.utils.CloseStreamInterface;
import test.utils.HashFile;

import java.io.*;
import java.net.Socket;
import java.util.Objects;

public class PeerServerHandler implements Runnable, CloseStreamInterface {

    private boolean res; /** 响应标志 */
    private boolean reqAck; /** 请求响应标志 */
    private Socket socket;

    private CommonMessage askFileExist = null;
    private CommonMessage reqSignal = null;

    {
        res = false;
        reqAck = false;
    }

    public PeerServerHandler(Socket socket) { this.socket = socket; }


    @Override
    public void run() {
        FileInputStream    fis = null; /** 读取文件流 */
        ObjectInputStream  ois = null; /** 输入对象流 */
        DataOutputStream   dos = null; /** socket输出流 */
        ObjectOutputStream oos = null; /** 输出对象流*/
        int                len = 0;    /** 文件读入的长度 */
        try {
            /** 打开流 */
            ois = new ObjectInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            FileFromTorrent fileFromTorrent = null;

            while (!res && !reqAck) {
                if (Objects.nonNull(askFileExist = (CommonMessage) ois.readObject())) {
                    fileFromTorrent = askFileExist.getFileFromTorrent();
                    fis = new FileInputStream(new File(fileFromTorrent.getPeerAbsoluteFileName()));
                    File file = new File(fileFromTorrent.getPeerAbsoluteFileName());
                    if(file.exists()) {
                        CommonMessage fileExist = CommonMessage.createFileExists(HashFile.getFileMD5(file));
                        oos.writeObject(fileExist);
                        System.out.println("服务端 :" + file.getName() + "存在，hash值" + fileExist.getInfo());
                    } else {
                        CommonMessage fileNotExist = CommonMessage.createFileNotExists();
                        oos.writeObject(fileNotExist);
                        System.out.println("服务端 :" + file.getName() + "不存在");
                        return;
                    }
                    this.res = true;
                    break;
                }
            }
            while (res && !reqAck) {
                if (Objects.nonNull(reqSignal = (CommonMessage) ois.readObject())) {
                    if(reqSignal.getMessageType().equals(MessageType.START_TRANS)) {
                        System.out.println("开始发送");
                        reqAck = true;
                    } else {
                        return;
                    }
                    break;
                }
            }
            byte[] sendBuffer = new byte[1024 * 8];
            /** 开始传输文件 */
            while ((len = fis.read(sendBuffer, 0, sendBuffer.length)) > 0) {
                dos.write(sendBuffer, 0, len);
                dos.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                closeObjectInputStream(ois);
                closeDataOutputStream(dos);
                closeObjectOutputStream(oos);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
