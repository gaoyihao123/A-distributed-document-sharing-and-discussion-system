package test.server;

import javafx.concurrent.Task;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class PeerServerTask implements Runnable {

    private static final Integer DEFAULT_PORT = 35789;

    private Integer port = null;

    public PeerServerTask() {
        this(DEFAULT_PORT);
    }

    public PeerServerTask(Integer port) {
        this.port = port;
    }

    @Override
    public void run() {
        ServerSocket server = null;
        try {
            server = new ServerSocket(this.port);
            while (true) {
                Socket socket = server.accept();
                new Thread(new PeerServerHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                server.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
            }
        }
    }

    public static void main(String[] args) {
        new Thread(new PeerServerTask()).start();
    }
}
