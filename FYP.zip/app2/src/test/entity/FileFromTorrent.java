package test.entity;

public class FileFromTorrent {

    /** 文件名称 */
    private String fileName;
    /** 文件所在宿主机上的文件名 */
    private String peerAbsoluteFileName;
    /** 文件所在宿主机的地址 */
    private String ipv4Addr;
    /** 文件所在宿主机的端口 */
    private String port;
    /** hash值 */
    private String hash;

    public FileFromTorrent(String fileName, String peerAbsoluteFileName, String ipv4Addr, String port, String hash) {
        this.fileName = fileName;
        this.peerAbsoluteFileName = peerAbsoluteFileName;
        this.ipv4Addr = ipv4Addr;
        this.port = port;
        this.hash = hash;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPeerAbsoluteFileName() {
        return peerAbsoluteFileName;
    }

    public void setPeerAbsoluteFileName(String peerAbsoluteFileName) {
        this.peerAbsoluteFileName = peerAbsoluteFileName;
    }

    public String getIpv4Addr() {
        return ipv4Addr;
    }

    public void setIpv4Addr(String ipv4Addr) {
        this.ipv4Addr = ipv4Addr;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    @Override
    public String toString() {
        return "FileFromTorrent{" +
                "fileName='" + fileName + '\'' +
                ", peerAbsoluteFileName='" + peerAbsoluteFileName + '\'' +
                ", ipv4Addr='" + ipv4Addr + '\'' +
                ", port='" + port + '\'' +
                ", hash='" + hash + '\'' +
                '}';
    }
}
