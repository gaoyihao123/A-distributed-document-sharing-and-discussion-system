package main.vo;

import javafx.beans.property.*;
import main.entity.FileFromTorrent;

import java.util.Objects;

public class FileDownloadVo {


    /** 文件名称 */
    private StringProperty fileName;
    /** 进度条 */
    private DoubleProperty progress;
    /** 是否勾选 */
    private BooleanProperty chosen;
    /** 解析的种子文件对象 */
    private FileFromTorrent fileFromTorrent;

    public FileDownloadVo(FileFromTorrent fileFromTorrent) {
        this(fileFromTorrent, 0, false);
    }

    public FileDownloadVo(FileFromTorrent fileFromTorrent, boolean chosen) {
        this(fileFromTorrent, 0, chosen);
    }

    public FileDownloadVo(
            FileFromTorrent fileFromTorrent,
            double progress,
            boolean chosen) {
        this.fileFromTorrent = fileFromTorrent;
        this.fileName = new SimpleStringProperty(fileFromTorrent.getFileName());
        this.progress = new SimpleDoubleProperty(progress);
        this.chosen = new SimpleBooleanProperty(chosen);
    }

    public String getFileName() {
        return fileName.get();
    }

    public StringProperty fileNameProperty() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName.set(fileName);
    }

    public double getProgress() {
        return progress.get();
    }

    public DoubleProperty progressProperty() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress.set(progress);
    }

    public boolean isChosen() {
        return chosen.get();
    }

    public BooleanProperty chosenProperty() {
        return chosen;
    }

    public void setChosen(boolean chosen) {
        this.chosen.set(chosen);
    }

    public FileFromTorrent getFileFromTorrent() {
        return fileFromTorrent;
    }

    public void setFileFromTorrent(FileFromTorrent fileFromTorrent) {
        this.fileFromTorrent = fileFromTorrent;
    }

    @Override
    public String toString() {
        return "FileDownloadVo{" +
                "fileName=" + fileName +
                ", progress=" + progress +
                ", chosen=" + chosen +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FileDownloadVo)) return false;
        FileDownloadVo that = (FileDownloadVo) o;
        return Objects.equals(getFileName(), that.getFileName()) &&
                Objects.equals(getProgress(), that.getProgress()) &&
                Objects.equals(isChosen(), that.isChosen()) &&
                Objects.equals(getFileFromTorrent(), that.getFileFromTorrent());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFileName(), getProgress(), isChosen(), getFileFromTorrent());
    }
}
