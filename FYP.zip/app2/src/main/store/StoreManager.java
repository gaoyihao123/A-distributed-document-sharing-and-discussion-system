package main.store;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.entity.FileFromTorrent;
import main.task.server.PeerServerTask;
import test.vo.FileDownloadVo;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class StoreManager {
    public static ObservableList downloadFileList = FXCollections.observableArrayList(new LinkedList<FileDownloadVo>());
    public static List<FileFromTorrent> fileFromTorrentList = null;
    public static PeerServerTask peerServerTask = null;
    public static String downloadPath = "D:/downloads/";
    public static String btAbsolutePath = "D:/gbt/";
    static {
        File file =new File(StoreManager.downloadPath);
        //如果文件夹不存在则创建
        System.out.println(file.exists());
        if  (!file .exists()  && !file .isDirectory()) {
            file.mkdir();
        }
    }
    static {
        File file =new File(StoreManager.btAbsolutePath);
        //如果文件夹不存在则创建
        System.out.println(file.exists());
        if  (!file .exists()  && !file .isDirectory()) {
            file.mkdir();
        }
    }
}
