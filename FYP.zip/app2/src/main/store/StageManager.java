package main.store;

import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class StageManager {
    public static Map<String, Stage> stageCache = new HashMap<>();
    public static String app = "";
    public static Map<String, String> stageChildren2Parent = new HashMap<>();
}
