package main.entity;

import java.io.Serializable;
import java.util.Objects;

public class FileFromTorrent implements Serializable {

    public static final long serialVersionUID = -5809782578272943999L;

    /** 文件名称 */
    private String fileName;
    /** 文件所在宿主机上的文件名 */
    private String peerAbsoluteFileName;
    /** 文件所在宿主机的地址 */
    private String ipv4Addr;
    /** 文件所在宿主机的端口 */
    private Integer port;
    /** hash值 */
    private String hash;

    private Long length;

    public FileFromTorrent(String fileName, String peerAbsoluteFileName, String ipv4Addr, Integer port, String hash, Long length) {
        this.fileName = fileName;
        this.peerAbsoluteFileName = peerAbsoluteFileName;
        this.ipv4Addr = ipv4Addr;
        this.port = port;
        this.hash = hash;
        this.length = length;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPeerAbsoluteFileName() {
        return peerAbsoluteFileName;
    }

    public void setPeerAbsoluteFileName(String peerAbsoluteFileName) {
        this.peerAbsoluteFileName = peerAbsoluteFileName;
    }

    public String getIpv4Addr() {
        return ipv4Addr;
    }

    public void setIpv4Addr(String ipv4Addr) {
        this.ipv4Addr = ipv4Addr;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public Long getLength() {
        return length;
    }

    public void setLength(Long length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return "FileFromTorrent{" +
                "fileName='" + fileName + '\'' +
                ", peerAbsoluteFileName='" + peerAbsoluteFileName + '\'' +
                ", ipv4Addr='" + ipv4Addr + '\'' +
                ", port=" + port +
                ", hash='" + hash + '\'' +
                ", length=" + length +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FileFromTorrent)) return false;
        FileFromTorrent that = (FileFromTorrent) o;
        return Objects.equals(getFileName(), that.getFileName()) &&
                Objects.equals(getPeerAbsoluteFileName(), that.getPeerAbsoluteFileName()) &&
                Objects.equals(getIpv4Addr(), that.getIpv4Addr()) &&
                Objects.equals(getPort(), that.getPort()) &&
                Objects.equals(getHash(), that.getHash()) &&
                Objects.equals(getLength(), that.getLength());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFileName(), getPeerAbsoluteFileName(), getIpv4Addr(), getPort(), getHash(), getLength());
    }
}
