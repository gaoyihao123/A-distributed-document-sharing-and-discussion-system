package main.entity;

public enum MessageType {

    FILE_EXIST_SIGNAL(200),
    REQUEST_SIGNAL(101),
    RESPONSE_SIGNAL(102),
    ASK_FILE_EXIST_SIGNAL(103),
    FILE_NOT_EXITS_SIGNAL(404),
    START_TRANS(201),
    CLIENT_CLOSE_SOCKET(500);

    private final int code;

    MessageType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

}
