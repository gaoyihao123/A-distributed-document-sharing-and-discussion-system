package main.entity;

import java.io.Serializable;

public class CommonMessage implements Serializable {

    public static final long serialVersionUID = -5809782578272943933L;

    private MessageType messageType;

    private FileFromTorrent fileFromTorrent;

    private String info;

    public CommonMessage(MessageType messageType, FileFromTorrent fileFromTorrent, String info) {
        this.messageType = messageType;
        this.fileFromTorrent = fileFromTorrent;
        this.info = info;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public FileFromTorrent getFileFromTorrent() {
        return fileFromTorrent;
    }

    public void setFileFromTorrent(FileFromTorrent fileFromTorrent) {
        this.fileFromTorrent = fileFromTorrent;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "CommonMessage{" +
                "messageType=" + messageType +
                ", fileFromTorrent=" + fileFromTorrent +
                ", info='" + info + '\'' +
                '}';
    }

    public static CommonMessage createFileExists(String hash) {
        return new CommonMessage(MessageType.FILE_EXIST_SIGNAL, null, hash);
    }

    public static CommonMessage createAskFileExists(FileFromTorrent file, String hash) {
        return new CommonMessage(MessageType.ASK_FILE_EXIST_SIGNAL, file, hash);
    }

    public static CommonMessage createFileNotExists() {
        return new CommonMessage(MessageType.FILE_NOT_EXITS_SIGNAL, null, null);
    }

    public static CommonMessage createClientCloseSocket() {
        return new CommonMessage(MessageType.CLIENT_CLOSE_SOCKET, null, null);
    }

    public static CommonMessage createStartTrans() {
        return new CommonMessage(MessageType.START_TRANS, null, null);
    }
}
