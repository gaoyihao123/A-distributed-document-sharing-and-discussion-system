package main.task.server;

import main.entity.CommonMessage;
import main.entity.FileFromTorrent;
import main.entity.MessageType;
import main.utils.CloseStreamInterface;
import main.utils.FileHash;
import test.utils.HashFile;

import java.io.*;
import java.net.Socket;
import java.util.Objects;

public class PeerServerHandler implements Runnable, CloseStreamInterface {

    private boolean res; /** 响应标志 */
    private boolean reqAck; /** 请求响应标志 */
    private Socket socket;

    byte[] sendBuffer = new byte[1024 * 8];

    {
        res = false;
        reqAck = false;
    }

    public PeerServerHandler(Socket socket) { this.socket = socket; }

    @Override
    public void run() {
        CommonMessage      askFileExist = null;
        CommonMessage      reqSignal = null;
        FileInputStream    fis = null; /** 读取文件流 */
        ObjectInputStream  ois = null; /** 输入对象流 */
        DataOutputStream   dos = null; /** socket输出流 */
        ObjectOutputStream oos = null; /** 输出对象流*/
        int                len = 0;
        try {
            /** 打开流 */
            ois = new ObjectInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            FileFromTorrent fileFromTorrent = null;

            while (!res && !reqAck) {
                if (Objects.nonNull(askFileExist = (CommonMessage) ois.readObject())) {
                    if(askFileExist.getMessageType().equals(MessageType.CLIENT_CLOSE_SOCKET)) {
                        socket.close();
                        return;
                    }
                    fileFromTorrent = askFileExist.getFileFromTorrent();
                    File file = new File(fileFromTorrent.getPeerAbsoluteFileName());
                    if(file.exists() && fileFromTorrent.getHash().equals(FileHash.getFileMD5(file))) {
                        fis = new FileInputStream(new File(fileFromTorrent.getPeerAbsoluteFileName()));
                        CommonMessage fileExist = CommonMessage.createFileExists(HashFile.getFileMD5(file));
                        oos.writeObject(fileExist);
                        System.out.println("服务端 :" + file.getName() + "存在，hash值" + fileExist.getInfo());
                    } else {
                        CommonMessage fileNotExist = CommonMessage.createFileNotExists();
                        oos.writeObject(fileNotExist);
                        System.out.println("服务端 :" + file.getName() + "不存在");
                        socket.close();
                        return;
                    }
                    this.res = true;
                    break;
                }
            }
            while (res && !reqAck) {
                if (Objects.nonNull(reqSignal = (CommonMessage) ois.readObject())) {
                    if(reqSignal.getMessageType().equals(MessageType.START_TRANS)) {
                        System.out.println("开始发送");
                        reqAck = true;
                    } else {
                        return;
                    }
                    break;
                }
            }
            while ((len = fis.read(sendBuffer, 0, sendBuffer.length)) > 0) {
                dos.write(sendBuffer, 0, len);
                dos.flush();
//                System.out.println("服务端 ： " + len);
            }
            while (true) {
                System.out.println(12312);
                if(Objects.nonNull(reqSignal = (CommonMessage) ois.readObject())) {
                    if(reqSignal.getMessageType().equals(MessageType.CLIENT_CLOSE_SOCKET)) {
                        System.out.println("请求停止");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                closeObjectInputStream(ois);
                closeDataOutputStream(dos);
                closeObjectOutputStream(oos);
                closeFileInputStream(fis);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
