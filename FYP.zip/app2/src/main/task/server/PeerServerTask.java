package main.task.server;

import javafx.concurrent.Task;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class PeerServerTask extends Task {

    public volatile boolean exit = false;

    private static final Integer DEFAULT_PORT = 35789;

    private Integer port = null;

    public PeerServerTask() {
        this(DEFAULT_PORT);
    }

    public PeerServerTask(Integer port) {
        this.port = port;
    }

    @Override
    protected Object call() throws Exception {
        ServerSocket server = null;
        try {
            server = new ServerSocket(this.port);
            while (!exit) {
                Socket socket = server.accept();
                if(socket!=null) {
                    new Thread(new PeerServerHandler(socket)).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("guanbi");
            server.close();
        }
        return null;
    }
}
