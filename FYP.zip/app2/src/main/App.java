package main;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import main.store.StageManager;
import main.store.StoreManager;
import main.task.client.PeerClientCloseTask;
import main.task.client.PeerClientTask;
import main.task.server.PeerServerTask;


public class App extends Application {

    private StageManager stageManager;

    @Override
    public void start(Stage primaryStage) throws Exception {
        stageManager.stageCache.put(getClass().getName(), primaryStage);
        stageManager.app = getClass().getName();
        Parent root = FXMLLoader.load(getClass().getResource("resources/main/main.fxml"));
        primaryStage.setTitle("Download Demo");
        primaryStage.setScene(new Scene(root));
        primaryStage.getIcons().add(new Image(
                App.class.getResourceAsStream("./resources/imgs/window_icon.png")));
        primaryStage.initStyle(StageStyle.DECORATED);
        primaryStage.setResizable(false);
        primaryStage.show();
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                StoreManager.peerServerTask.exit = true;
                new Thread(new PeerClientCloseTask()).start();
            }
        });
    }

    public static void main(String[] args) {
        StoreManager.peerServerTask = new PeerServerTask();
        new Thread(StoreManager.peerServerTask).start();
        launch(App.class);
    }
}
