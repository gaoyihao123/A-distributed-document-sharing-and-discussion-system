package main.controller;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import main.entity.FileFromTorrent;
import main.store.StageManager;
import main.store.StoreManager;
import main.utils.DirectoryUtils;
import main.utils.FileHash;
import main.utils.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class GenerateController implements Initializable {

    @FXML
    private AnchorPane pane;
    @FXML
    private VBox torrentFile;
    @FXML
    private Button sureButton;
    @FXML
    private Button cancelButton;

    private String [] fileList;

    private Label placeholder;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        placeholder = new Label("请拖入要生成种子文件的文件");
        torrentFile.getChildren().addAll(placeholder);
        torrentFile.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                if (event.getGestureSource() != torrentFile
                        && event.getDragboard().hasFiles()) {
                    /* allow for both copying and moving, whatever user chooses */
                    event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                }
                event.consume();
            }
        });
        torrentFile.setOnDragDropped(new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasFiles()) {
                    String fileListString = db.getFiles().toString();
                    fileList = fileListString.substring(1, fileListString.length()-1).split(",");
                    StringBuffer str = new StringBuffer();
                    for (int i = 0; i < fileList.length; i++) {
                        fileList[i] = fileList[i].trim();
                    }
                    for (String s : fileList) {
                        str.append(s + "\n");
                    }
                    placeholder.setText(str.toString());
                    success = true;
                }
                /* let the source know whether the string was successfully
                 * transferred and used */
                event.setDropCompleted(success);

                event.consume();
            }
        });
    }

    public void  sureButtonClick() {
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)sureButton.getScene().getWindow();
        final ProgressIndicator pin =  new ProgressIndicator();
        pin.setProgress(-1.0);
        torrentFile.setSpacing(5);
        torrentFile.setAlignment(Pos.CENTER);
        torrentFile.getChildren().remove(placeholder);
        torrentFile.getChildren().add(pin);

        new Thread(new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                String btPath = generate();
                if(btPath!=null) {
                    Platform.runLater(() -> {
                        curStage.close();
                        Alert alert = new Alert(
                                Alert.AlertType.NONE,
                                "生成种子文件成功：" + btPath,
                                new ButtonType("确定", ButtonBar.ButtonData.YES)
                        );
                        alert.setTitle("生成种子文件");
                        alert.initOwner(StageManager.stageCache.get(StageManager.app));
                        Optional<ButtonType> buttonType = alert.showAndWait();
                        if(buttonType.get().getButtonData().equals(ButtonBar.ButtonData.YES)){
                            DirectoryUtils.openDirectory(new File(btPath).getParentFile().getAbsolutePath());
                        }
                        else {

                        }
                    });;
                }
                return null;
            }
        }).start();
    }

    public void cancelButtonClick() {
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)cancelButton.getScene().getWindow();
        curStage.close();
    }

    public String generate() {
        List<FileFromTorrent> l = new ArrayList<>();
        for (String s : fileList) {
            File file = new File(s);

            if(file.exists()) {
                String hash = FileHash.getFileMD5(file);
                FileFromTorrent fileFromTorrent = new FileFromTorrent(
                        file.getName(),
                        file.getAbsolutePath(),
                        "192.168.0.110",
                        35789,
                        "hash",
                        file.length()
                );
                l.add(fileFromTorrent);
            } else {
                return null;
            }
        }
        String btpath = StoreManager.btAbsolutePath+System.currentTimeMillis()+".gbt";
        FileUtils.generateBTFile(l, btpath);
        return btpath;
    }
}
