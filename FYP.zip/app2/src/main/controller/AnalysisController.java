package main.controller;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import main.entity.FileFromTorrent;
import main.store.StageManager;
import main.store.StoreManager;
import main.utils.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AnalysisController implements Initializable {

    @FXML
    private Button selectFileButton;
    @FXML
    private AnchorPane pane;
    @FXML
    private VBox torrentFile;
    @FXML
    private Button sureButton;
    @FXML
    private Button cancelButton;

    private String gbtFile;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Label placeholder = new Label("请拖入种子文件");
        torrentFile.getChildren().addAll(placeholder);
        torrentFile.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                if (event.getGestureSource() != torrentFile
                        && event.getDragboard().hasFiles()) {
                    /* allow for both copying and moving, whatever user chooses */
                    event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                }
                event.consume();
            }
        });

        torrentFile.setOnDragDropped(new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasFiles()) {
                    String fileListString = db.getFiles().toString();
                    gbtFile = fileListString.substring(1, fileListString.length()-1).split(",")[0];
                    placeholder.setText(gbtFile);
                    StoreManager.btAbsolutePath = gbtFile;
                    success = true;
                }
                /* let the source know whether the string was successfully
                 * transferred and used */
                event.setDropCompleted(success);

                event.consume();
            }
        });
        selectFileButton.addEventFilter(MouseEvent.MOUSE_CLICKED,  e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            File file = fileChooser.showOpenDialog(new Stage());
            if(file!=null) {
                placeholder.setText(file.getAbsolutePath());
                gbtFile = file.getAbsolutePath();
                StoreManager.btAbsolutePath = file.getAbsolutePath();
            }
        });
    }

    public void sureButtonClick() {
        StoreManager.fileFromTorrentList = FileUtils.analysisBTFile(gbtFile);
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)sureButton.getScene().getWindow();
        curStage.close();
        try {
            Stage stage = new Stage();
//            StageManager.stageChildren2Parent.put(getClass().getName(), StageManager.app);
            StageManager.stageChildren2Parent.put("app.controller.AnalysisController", StageManager.app);
            StageManager.stageCache.put(getClass().getName(), stage);
            stage.setTitle("下载");
            Parent downloadStage = FXMLLoader.load(getClass().getResource("../resources/download/download.fxml"));
            stage.setScene(new Scene(downloadStage));
            stage.initStyle(StageStyle.DECORATED);
            stage.getIcons().add(new Image(
                    getClass().getResourceAsStream("../resources/imgs/download_icon.png")));
            stage.initOwner(StageManager.stageCache.get(StageManager.app));
            stage.setResizable(false);
            stage.show();
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
        }
    }

    public void cancelButtonClick() {
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)cancelButton.getScene().getWindow();
        curStage.close();
    }
}
