package main.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import main.entity.FileFromTorrent;
import main.store.StageManager;
import main.store.StoreManager;
import main.vo.FileDownloadVo;

import java.io.File;
import java.net.URL;
import java.util.*;

public class DownloadController implements Initializable{

    @FXML
    private Button selectDownloadDirectory;
    @FXML
    private Pane anchorPaneBtn;
    @FXML
    private Pane pane;
    @FXML
    private TextField selectDirectory;
    @FXML
    private TableView<FileDownloadVo> downloadTable;
    @FXML
    private TableColumn<FileDownloadVo, String> downloadAbsoluteFile;
    @FXML
    private TableColumn<FileDownloadVo, Boolean> downloadChosen;
    @FXML
    private Button cancelButton;
    @FXML
    private Button sureButton;

    private List<FileFromTorrent> fileList = new ArrayList<>();
    private List<FileDownloadVo> downLoadFileList = new LinkedList<FileDownloadVo>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        /** 绑定大小 */
        anchorPaneBtn.prefWidthProperty().bind(pane.prefWidthProperty());

        this.initDownloadDirectoryEvent();
        this.analysisFromTorrent();
        this.initDownloadFileSelectEvent();
    }

    public void initDownloadDirectoryEvent() {
        selectDirectory.setText(StoreManager.downloadPath);
        selectDownloadDirectory.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("Choose Folder");
            File directory = directoryChooser.showDialog(new Stage());
            if (directory != null) {
                selectDirectory.setText(directory.getAbsolutePath());
                StoreManager.downloadPath = directory.getAbsolutePath();
            }
        });
    }

    public void analysisFromTorrent() {
        fileList = StoreManager.fileFromTorrentList;
//        fileList.add(new FileFromTorrent("2.exe", "D:/ChangZhi.rar", "127.0.0.1", 35789, "1", 640216l));
//        fileList.add(new FileFromTorrent("3.exe", "D:/ChangZhi.rar", "127.0.0.1", 35789, "1", 640216l));
   }

    public void initDownloadFileSelectEvent() {
        downLoadFileList.clear();
        List<FileDownloadVo> arraylist = new ArrayList<>();
        fileList.forEach((e) -> {
            arraylist.add(new FileDownloadVo(e, false));
        });
        ObservableList list = FXCollections.observableArrayList(arraylist);
        downloadTable.setItems(list);
        downloadChosen.setCellValueFactory(cellData -> cellData.getValue().chosenProperty());
        downloadAbsoluteFile.setCellValueFactory(cellData -> cellData.getValue().fileNameProperty());
        downloadChosen.setCellFactory(new Callback<TableColumn<FileDownloadVo, Boolean>, TableCell<FileDownloadVo, Boolean>>() {
            @Override
            public TableCell<FileDownloadVo, Boolean> call(TableColumn<FileDownloadVo, Boolean> param) {
                return new TableCell<FileDownloadVo, Boolean>() {

                    final CheckBox cell = new CheckBox();
                    {
                        setAlignment(Pos.CENTER);
                        cell.setOnAction( e -> {
                            FileDownloadVo vo = getTableView().getItems().get(getIndex());
                            if(vo.chosenProperty().get() == false) {
                                downLoadFileList.add(vo);
                                cell.setSelected(true);
                                vo.setChosen(true);
                            } else {
                                int idx;
                                for(idx=0; idx<downLoadFileList.size(); idx++) {
                                    if(downLoadFileList.get(0).equals(vo)) {
                                        break;
                                    }
                                }
                                if(idx<downLoadFileList.size()) {
                                    downLoadFileList.remove(idx);
                                }
                                cell.setSelected(false);
                                vo.setChosen(false);
                            }
                        });

                    }

                    @Override
                    public void updateItem(Boolean item, boolean empty) {
                        super.updateItem(item, empty);
                        if(!empty) {
                            FileDownloadVo vo = getTableView().getItems().get(getIndex());
                            String fileName = vo.getFileName();
                            setGraphic(cell);
                        } else {

                        }
                    }
                };
            }
        });
    }

    public void sureButtonClick() {
        System.out.println(downLoadFileList.size());
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)sureButton.getScene().getWindow();
        curStage.close();
        StoreManager.downloadFileList.addAll(downLoadFileList);
    }

    public void cancelButtonClick() {
        StageManager.stageChildren2Parent.remove(this.getClass().getName());
        StageManager.stageCache.remove((this.getClass().getName()));
        Stage curStage = (Stage)sureButton.getScene().getWindow();
        curStage.close();
    }

}
