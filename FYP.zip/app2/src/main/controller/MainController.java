package main.controller;


import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import main.store.StageManager;
import main.store.StoreManager;
import main.task.client.PeerClientTask;
import main.vo.FileDownloadVo;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable{
    @FXML
    private Button generateButton;
    @FXML
    private Button searchButton;
    @FXML
    private Button downloadButton;
    @FXML
    private Button analysisButton;
    @FXML
    private Separator barSeparator;
    @FXML
    private Pane pane;
    @FXML
    private VBox vBoxBar;
    @FXML
    private TableView<FileDownloadVo> tableView;
    @FXML
    private TableColumn<FileDownloadVo, String> fileName;
    @FXML
    private TableColumn<FileDownloadVo, Number> progress;

    private StageManager stageManager;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.initButtonStyleAndEvent();
        this.initTableView();
        vBoxBar.prefWidthProperty().bind(pane.widthProperty());
        tableView.prefWidthProperty().bind(pane.widthProperty());
        StoreManager.downloadFileList.addListener(new ListChangeListener() {
            @Override
            public void onChanged(Change c) {
                try {
                    handleDownloadTable();
                } catch (Exception e) {
                    System.out.println(e);
                }

            }
        });

    }

    public void initButtonStyleAndEvent() {
        this.initGenerateButtonStyleAndEvent();
        this.initAnalysisButtonStyleAndEvent();
        this.initDownloadButtonStyleAndEvent();
        this.initSearchButtonStyleAndEvent();
    }

    public void initGenerateButtonStyleAndEvent() {
        Image image = new Image(getClass().getResourceAsStream("../resources/imgs/generate_icon6.png"), 20, 20, true, true);
        ImageView imageView = new ImageView(image);
        generateButton.setGraphic(imageView);
        generateButton.addEventFilter(MouseEvent.MOUSE_ENTERED, e -> {
            generateButton.setScaleX(1.1);
            generateButton.setScaleY(1.1);
        });
        generateButton.addEventFilter(MouseEvent.MOUSE_EXITED, e -> {
            generateButton.setScaleX(1);
            generateButton.setScaleY(1);
        });
        generateButton.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            try {
                Stage stage = new Stage();
                stageManager.stageChildren2Parent.put(getClass().getName(), stageManager.app);
                stageManager.stageCache.put(getClass().getName(), stage);
                stage.setTitle("生成种子文件");
                Parent downloadStage = FXMLLoader.load(getClass().getResource("../resources/generate/generate.fxml"));
                stage.setScene(new Scene(downloadStage));
                stage.initStyle(StageStyle.DECORATED);
                stage.getIcons().add(new Image(
                        getClass().getResourceAsStream("../resources/imgs/generate_icon6.png")));
                stage.initOwner(stageManager.stageCache.get(stageManager.app));
                stage.setResizable(false);
                stage.show();
            } catch (IOException e1) {
                e1.printStackTrace();
            } finally {
            }
        });
    }

    public void initSearchButtonStyleAndEvent() {
        Image image = new Image(getClass().getResourceAsStream("../resources/imgs/search_icon.jpg"), 20, 20, true, true);
        ImageView imageView = new ImageView(image);
        searchButton.setGraphic(imageView);
        searchButton.addEventFilter(MouseEvent.MOUSE_ENTERED, e -> {
            searchButton.setScaleX(1.1);
            searchButton.setScaleY(1.1);
        });
        searchButton.addEventFilter(MouseEvent.MOUSE_EXITED, e -> {
            searchButton.setScaleX(1);
            searchButton.setScaleY(1);
        });
    }

    public void initAnalysisButtonStyleAndEvent() {
        Image image = new Image(getClass().getResourceAsStream("../resources/imgs/analysis_icon.png"), 20, 20, true, true);
        ImageView imageView = new ImageView(image);
        analysisButton.setGraphic(imageView);
        analysisButton.addEventFilter(MouseEvent.MOUSE_ENTERED, e -> {
            analysisButton.setScaleX(1.1);
            analysisButton.setScaleY(1.1);
        });
        analysisButton.addEventFilter(MouseEvent.MOUSE_EXITED, e -> {
            analysisButton.setScaleX(1);
            analysisButton.setScaleY(1);
        });
        analysisButton.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            System.out.println("click analysis");
            try {
                Stage stage = new Stage();
                stageManager.stageChildren2Parent.put(getClass().getName(), stageManager.app);
                stageManager.stageCache.put(getClass().getName(), stage);
                stage.setTitle("分析");
                Parent analysisStage = FXMLLoader.load(getClass().getResource("../resources/analysis/analysis.fxml"));
                stage.setScene(new Scene(analysisStage));
                stage.initStyle(StageStyle.DECORATED);
                stage.getIcons().add(new Image(
                        getClass().getResourceAsStream("../resources/imgs/analysis_icon.png")));
                stage.initOwner(stageManager.stageCache.get(stageManager.app));
                stage.setResizable(false);
                stage.show();
            } catch (IOException e1) {
                e1.printStackTrace();
            } finally {
            }
        });
    }

    public void initDownloadButtonStyleAndEvent() {
        Image image = new Image(getClass().getResourceAsStream("../resources/imgs/download_icon.png"), 20, 20, true, true);
        ImageView imageView = new ImageView(image);
        downloadButton.setGraphic(imageView);
        downloadButton.addEventFilter(MouseEvent.MOUSE_ENTERED, e -> {
            downloadButton.setScaleX(1.1);
            downloadButton.setScaleY(1.1);
        });
        downloadButton.addEventFilter(MouseEvent.MOUSE_EXITED, e -> {
            downloadButton.setScaleX(1);
            downloadButton.setScaleY(1);
        });
        downloadButton.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            try {
                Stage stage = new Stage();
                stageManager.stageChildren2Parent.put(getClass().getName(), stageManager.app);
                stageManager.stageCache.put(getClass().getName(), stage);
                stage.setTitle("下载");
                Parent downloadStage = FXMLLoader.load(getClass().getResource("../resources/download/download.fxml"));
                stage.setScene(new Scene(downloadStage));
                stage.initStyle(StageStyle.DECORATED);
                stage.getIcons().add(new Image(
                        getClass().getResourceAsStream("../resources/imgs/download_icon.png")));
                stage.initOwner(stageManager.stageCache.get(stageManager.app));
                stage.setResizable(false);
                stage.show();
            } catch (IOException e1) {
                e1.printStackTrace();
            } finally {
            }
        });
    }

    public void initTableView() {
        tableView.setPlaceholder(new Label("暂无下载项"));
    }

    public void  handleDownloadTable() throws Exception{

        ObservableList<FileDownloadVo> fileList = StoreManager.downloadFileList;
        tableView.setItems(fileList);
        fileName.setCellValueFactory(cellData -> cellData.getValue().fileNameProperty());
        progress.setCellValueFactory(cellData -> cellData.getValue().progressProperty());
        progress.setCellFactory(new Callback<TableColumn<FileDownloadVo, Number>, TableCell<FileDownloadVo, Number>>() {
            /** 因为是使用自定义的工厂方法，所以样式，创建过程都放在下面的函数里面 */
            @Override
            public TableCell<FileDownloadVo, Number> call(TableColumn<FileDownloadVo, Number> param) {
                return new TableCell<FileDownloadVo, Number>() {

                    final ProgressBar progressBar = new ProgressBar(0);
                    final GridPane progressBarCell = new GridPane();
                    final Label progressLabel = new Label();
                    {
                        progressBar.setStyle("-fx-accent: #409eff; -fx-box-border: white;");
                        progressBar.setPrefWidth(progress.getPrefWidth()-20);
                        progressLabel.setAlignment(Pos.CENTER);
                        progressLabel.setStyle("-fx-text-fill: #333333");
                        progressLabel.setPrefWidth(progress.getPrefWidth()-20);
                        progressBarCell.setAlignment(Pos.CENTER);
                        progressBarCell.add(progressBar, 0, 0, 5, 1);
                        progressBarCell.add(progressLabel, 3, 0, 1, 1);
                        setAlignment(Pos.CENTER);
                    }

                    /** 更新函数，当绑定的progressProperty动态改变时，肾小管hi奥 */
                    @Override
                    public void updateItem(Number item, boolean empty) {
                        super.updateItem(item, empty);

                        if(!empty) {
                            double percent = (double)item;
                            FileDownloadVo vo = getTableView().getItems().get(getIndex());
                            String fileName = vo.getFileName();
                            progressBar.setProgress((double)item);
                            if(percent != 1.0) {
                                progressLabel.setText(String.format("%.2f", percent*100)+"%");
                            } else {
                                progressLabel.setText("complete");
                            }
                            setGraphic(progressBarCell);
                        } else {

                        }
                    }
                };
            }
        });

        for (Object o : StoreManager.downloadFileList) {
            FileDownloadVo b = (FileDownloadVo) o;
            Task task = new PeerClientTask(b.getFileFromTorrent(), StoreManager.downloadPath);
            /** 基于javafx的并发task，动态更新ui，不然会阻塞渲染进程 */
            task.progressProperty().addListener(new ChangeListener<Number>() {
                @Override
                public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                    b.setProgress(newValue.doubleValue());
                }
            });
            new Thread(task).start();
        }

    }
}
