package main.utils;

import main.entity.FileFromTorrent;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {

    public static boolean generateBTFile(FileFromTorrent file, String absolutePath) {
        return true;
    }

    public static boolean generateBTFile(List<FileFromTorrent> fileList, String absolutePath) {
        for (FileFromTorrent fileFromTorrent : fileList) {
            fileFromTorrent.setHash(FileHash.getFileMD5(new File(fileFromTorrent.getPeerAbsoluteFileName())));
        }
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(absolutePath));
            oos.writeObject(fileList);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                oos.flush();
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
            }
        }
        return true;
    }

    public static List<FileFromTorrent> analysisBTFile(String absolutePath) {
        ObjectInputStream ois = null;
        List<FileFromTorrent> list = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(absolutePath));
            list = (ArrayList<FileFromTorrent>)ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
            }
        }
        return list;
    }
    
    

    public static void main(String[] args) {
        List<FileFromTorrent> list = new ArrayList<FileFromTorrent>() {{
           add( new FileFromTorrent("1.zip", "D:\\1.zip", "127.0.0.1", 35789, "1321q3", 12312l));
           add( new FileFromTorrent("1.zip", "D:\\1.zip", "127.0.0.1", 35789, "1321q3", 12312l));
           add( new FileFromTorrent("1.zip", "D:\\1.zip", "127.0.0.1", 35789, "1321q3", 12312l));
        }};

        generateBTFile(list, "D://tmp.gbt");

        for (FileFromTorrent fileFromTorrent : analysisBTFile("D://tmp.gbt")) {
            System.out.println(fileFromTorrent);
        }
    }
}
