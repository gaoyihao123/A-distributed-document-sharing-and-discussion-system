package main.utils;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class DirectoryUtils {
    public static void openDirectory(String path) {
        try {
            File file = new File(path);
            Desktop.getDesktop().open(file);
        } catch (IOException | NullPointerException e) { // 异常处理
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        System.out.println(new File("D:/gbt/1584927414868.gbt").getParentFile().getAbsolutePath());
        openDirectory(new File("D:/gbt/1584927414868.gbt").getParentFile().getAbsolutePath());
    }
}
