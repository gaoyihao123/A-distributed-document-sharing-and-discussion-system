package main.utils;

import java.io.*;
import java.util.Objects;

public interface CloseStreamInterface {

    default void closeObjectInputStream(ObjectInputStream ois) throws IOException {
        if (Objects.nonNull(ois)) {
            try {
                ois.close();
            } catch (IOException ex) {
                throw new IOException("关闭对象读入流失败\n" + ex);
            }
        }
    }

    default void closeDataOutputStream(DataOutputStream oos) throws IOException {
        if (Objects.nonNull(oos)) {
            try {
                oos.flush();
                oos.close();
            } catch (IOException ex) {
                throw new IOException("关闭socket输出流失败\n" + ex);
            }
        }
    }

    default void closeObjectOutputStream(ObjectOutputStream oos) throws IOException {
        if (Objects.nonNull(oos)) {
            try {
                oos.flush();
                oos.close();
            } catch (IOException ex) {
                throw new IOException("关闭对象输出流失败\n" + ex);
            }
        }
    }

    default void closeFileInputStream(FileInputStream fis) throws IOException {
        if (Objects.nonNull(fis)) {
            try {
                fis.close();
            } catch (IOException ex) {
                throw new IOException("关闭对象输出流失败\n" + ex);
            }
        }
    }

    default void closeDataInputStream(DataInputStream dis) throws IOException {
        if (Objects.nonNull(dis)) {
            try {
                dis.close();
            } catch (IOException ex) {
                throw new IOException("关闭socket输入流失败\n" + ex);
            }
        }
    }

    default void closeFileOutputStream(FileOutputStream fos) throws IOException {
        if (Objects.nonNull(fos)) {
            try {
                fos.close();
            } catch (IOException ex) {
                throw new IOException("关闭文件输出流失败\n" + ex);
            }
        }
    }
}
